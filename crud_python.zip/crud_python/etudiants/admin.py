from django.contrib import admin

# Register your models here.
from etudiants.models import Etudiant
admin.site.register(Etudiant)

