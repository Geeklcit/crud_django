from django.urls import path

from . import views

urlpatterns = [
    path('', views.EtudiantList.as_view(), name='etudiant_list'),
    path('view/<int:pk>', views.EtudiantView.as_view(), name='etudiant_view'),
    path('new', views.EtudiantCreate.as_view(), name='etudiant_new'),
    path('view/<int:pk>', views.EtudiantView.as_view(), name='etudiant_view'),
    path('edit/<int:pk>', views.EtudiantUpdate.as_view(), name='etudiant_edit'),
    path('delete/<int:pk>', views.EtudiantDelete.as_view(), name='etudiant_delete'),
]