from django.apps import AppConfig


class EtudiantsConfig(AppConfig):
    name = 'etudiants'
