from django.db import models

# Create your models here.
from django.urls import reverse

class Etudiant(models.Model):
    nom = models.CharField(max_length=100)
    age = models.IntegerField()
    prenom = models.CharField(max_length=100)
    classe = models.CharField(max_length=100)

    def __str__(self):
        return self.nom

    def get_absolute_url(self):
        return reverse('etudiant_edit', kwargs={'pk': self.pk})