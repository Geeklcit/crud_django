from django.shortcuts import render

# Create your views here.

from django.http import HttpResponse
from django.views.generic import ListView, DetailView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy

from etudiants.models import Etudiant

class EtudiantList(ListView):
    model = Etudiant

class EtudiantView(DetailView):
    model = Etudiant

class EtudiantCreate(CreateView):
    model = Etudiant
    fields = ['nom', 'prenom','age', 'classe']
    success_url = reverse_lazy('etudiant_list')

class EtudiantUpdate(UpdateView):
    model = Etudiant
    fields = ['nom', 'prenom', 'age', 'classe']
    success_url = reverse_lazy('etudiant_list')

class EtudiantDelete(DeleteView):
    model = Etudiant
    success_url = reverse_lazy('etudiant_list')
